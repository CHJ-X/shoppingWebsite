class MySQLConfig(object):
  DEBUG = True
  SECRET_KEY = "CHJ12138QWERTYUIADSFGHJK"
  SQLALCHEMY_DATABASE_URI = "mysql+pymysql://{username}:{password}@{ip}:{port}/{db}"\
    .format(username="root", password="1693189780a", ip="localhost", port="3306", db="eshop")
  SQLALCHEMY_TRACK_MODIFICATIONS = False
  SQLALCHEMY_ECHO = True

WHITE_NAME_LIST = ["/login/admin","/login","/register","/goods/type"]